
Raccoon - v38 416x416-resize
==============================

This dataset was exported via roboflow.ai on June 15, 2021 at 6:11 AM GMT

It includes 196 images.
Raccoons are annotated in retinanet format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

No image augmentation techniques were applied.


